package edu.umsl.inheritance;

public class Shape {
	private String border_color;
	
	
	
	public String getBorder_color() {
		return border_color;
	}

	public void setBorder_color(String border_color) {
		this.border_color = border_color;
	}

	
}



