package edu.umsl.inheritance;

public class App {

	
	
	public static void main(String[] args) {
		Circle c = new Circle();
		c.setBorder_color("blue");
		c.setRadius(5);
		
		
	
		 double area = c.getRadius() * Math.PI * c.getRadius();
		 
		 
		 Square s = new Square();
		 s.setBorder_color("Red");
		 s.setSide(10);
		 
		 double areaSquare = s.getSide() * s.getSide();
		 
		 Rectangle r = new Rectangle();
		 r.setBorder_color("Green");
		 r.setBreadth(3);
		 r.setLength(5);
		 
		 
		 double areaRectangle = r.getBreadth() * r.getLength();
		 		
		 
		 
		System.out.println("Circle");
		System.out.println(c.getBorder_color());
		System.out.println(c.getRadius());
		System.out.println(area);
		
		
		System.out.println();
		
		System.out.println("Square");
		System.out.println(s.getBorder_color());
		System.out.println(s.getSide());
		System.out.println(areaSquare);
		
		System.out.println();
		
		System.out.println("Rectangle");
		System.out.println(r.getBorder_color());
		System.out.println(r.getBreadth());
		System.out.println(r.getLength());
		System.out.println(areaRectangle);
		
		
		
		
		}



	
	
		
		
		
}	
		